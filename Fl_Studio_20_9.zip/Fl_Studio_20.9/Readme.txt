ARCHIVE PASSWORD: 11111

INSTRUCTIONS:

Turn off your Anti-Virus if you are now allowed to download. Your computer will sometimes see the file as a potential threat even though it's completely safe!